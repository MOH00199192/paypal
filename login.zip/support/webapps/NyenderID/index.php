<?php

header("location: websrc");
exit;

?>